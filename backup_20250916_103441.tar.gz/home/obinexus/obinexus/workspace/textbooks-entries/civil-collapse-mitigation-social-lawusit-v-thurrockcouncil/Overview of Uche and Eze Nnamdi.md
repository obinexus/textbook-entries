# Overview of Uche and Eze Nnamdi

# Who is Uche Nnamdi?

Uche Nnamdi or Knowledge Nnamdi is a digital illustrated Avatar of \`me\` Nnamdi Michael Okpala\` wearing my custom-made woven outfit. Uche Nnamdi sheds light on Knowledge in various domain. As I Nnamdi am a prince in Omanbala (Anambra) State from Nnewi, by design using Uche Nnamdi entire look complements me preserve the Igbo Culture. Its emphasis changes in become young child to adult male.

Primary, his role on social media is to convey concept through when prompted on my Social Media Videos. Uche Nnamdi appears in other forms of my media, print and design. Uche Nnamdi to converse a conversation for courses. Uche Nnamdi is a reflection of my Igbo spirit, and courage.

Secondly, Since I diagnosed with Autism, ADHD (Attention Deficit Hyperactive Disorder), and Asperger's with a Learning Disability and decided to never ‘mask’ again hiding my true Nature. Uche Nnamdi express everything I do and love my intricate set of judgement. As an autistic adult, Uche Nnamdi shows his way through his site, guiding users on what they might not necessarily understand. Uche Nnamdi wears Isi-agu pattern. I will incorporate Nsibidi writing in the attires of Uche Nnamdi.
# Who is Eze Nnamdi?

Eze/King Nnamdi is a reflection and embodiment of who I am truly inside and out. It is a primary a portrait using narrative concept art which has a poem. Eze Nnamdi which I am uses the artistic medium to capture the story and return of an Igbo king in his homeland, Nnewi, Omanbala, Biafra or Nnewi, Anambra Nigeria. He is to be primary depicted on pen and paper then refined to get the key concept down on paper then digital drawn in Clip Studio Paint.		

# Uche Nnamdi and Eze Attire/Outfit: 

# What does Uche Nnamdi wear?

Uche Nnamdi wears only traditional Attire consisting of various Motifs from various parts of the globe. The motifs tell my story using seamless intertwined patterns. The Proof of Concept for Uche Nnamdi stems from deep Igbo root, and the stories told by me, and my physiological/ mental health, and state of being. 

Uche Nnamdi Attires Is separated into three different section of layer using design principle. These are background, midground, and foreground. Each layer is woven seamlessly into another by 2 more pattern left and right between foreground and midground, and midground and background.

This is the pattern used for the logo for Nexus Labs. It will have Nsibidi character in a circular frame and a core connecting concept in the middle. In the circular frame, there is a journey wrapped in a story and return of a real king me, which is connected to the centre by the two other pattern, that bridge the foreground, midground and background.

## What does Eze Nnamdi wear?

Eze Nnamdi is wearing **only** Igbo attires. I will incorporate Nsibidi writing, in the design as tattoo, clothing and environmental art. The requires learning Nsibidi, and its cultural significance. As I narrative concept artist. I would represent myself truly in statue and positioning my self as high ranking as in real life. I intend to sell the picture, and give it a narrative story my kingship and natural born leadership. 